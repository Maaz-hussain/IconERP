package com.iconerp.iconerp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IconErpApplicationTests {

	@Test
	void contextLoads() {
	}

}
